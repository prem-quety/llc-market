__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/443447a3dd6c22df.js",
  "static/chunks/turbopack-6883bd24d398a4ca.js"
])
